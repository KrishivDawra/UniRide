import React from "react";
import { Link } from "react-router-dom";
import {
  Car,
  ShieldCheck,
  MapPin,
  Clock,
  Users,
  GraduationCap,
  Star,
  Leaf,
  ArrowRight,
  CheckCircle,
  Sparkles,
} from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-violet-50 overflow-hidden text-slate-900">
      {/* Hero */}
      <section className="relative max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 py-16 lg:py-24 grid lg:grid-cols-2 gap-14 items-center">
        {/* Background blobs */}
        <div className="pointer-events-none absolute top-0 -left-10 w-80 h-80 bg-blue-300/30 rounded-full blur-3xl -z-10" />
        <div className="pointer-events-none absolute bottom-0 -right-10 w-96 h-96 bg-violet-300/30 rounded-full blur-3xl -z-10" />
        <div className="pointer-events-none absolute top-1/2 left-1/2 w-72 h-72 bg-emerald-200/20 rounded-full blur-3xl -z-10" />

        {/* Left */}
        <div className="text-center lg:text-left">
          <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur border border-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold mb-6 shadow-sm">
            <Sparkles size={16} className="text-violet-600" />
            Verified College Ride Sharing
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-[1.1] tracking-tight">
            Your Campus.
            <br />
            Your Ride.
            <br />
            <span className="bg-gradient-to-r from-blue-600 via-violet-600 to-emerald-500 bg-clip-text text-transparent">
              Your Community.
            </span>
          </h1>

          <p className="mt-6 text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl mx-auto lg:mx-0">
            UniRide connects verified students and trusted drivers for safe,
            affordable, and convenient college rides across your campus routes.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center lg:justify-start">
            <Link
              to="/register"
              className="group bg-gradient-to-r from-blue-600 to-violet-600 text-white px-7 py-3.5 rounded-2xl font-semibold shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-violet-500/30 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
            >
              Join UniRide
              <ArrowRight size={18} className="group-hover:translate-x-1 transition" />
            </Link>

            <Link
              to="/login"
              className="bg-white text-slate-800 border border-slate-200 px-7 py-3.5 rounded-2xl font-semibold hover:bg-slate-50 hover:border-slate-300 shadow-sm hover:shadow-md transition-all"
            >
              Login
            </Link>
          </div>

          {/* Stats */}
          <div className="mt-10 grid grid-cols-3 gap-3 sm:gap-4 max-w-md mx-auto lg:mx-0">
            <StatCard value="120+" label="Students" color="text-blue-600" />
            <StatCard value="35+" label="Drivers" color="text-violet-600" />
            <StatCard value="₹80" label="Avg Save" color="text-emerald-600" />
          </div>
        </div>

        {/* Right card */}
        <div className="relative">
          <div className="absolute -top-6 -right-2 sm:-right-6 bg-white rounded-2xl shadow-xl shadow-blue-500/10 px-4 py-3 border border-slate-100 flex items-center gap-3 z-10">
            <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
              <CheckCircle size={20} />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900">Verified Ride</p>
              <p className="text-xs text-slate-500">College ID checked</p>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-xl rounded-[2rem] shadow-2xl shadow-blue-500/10 p-6 sm:p-8 border border-white">
            <div className="flex items-center justify-between gap-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-blue-600 to-violet-600 text-white p-3 rounded-2xl shadow-lg shadow-blue-500/30">
                  <Car size={26} />
                </div>
                <div>
                  <h2 className="font-bold text-lg sm:text-xl">Live Ride Preview</h2>
                  <p className="text-slate-500 text-sm">Chitkara University route</p>
                </div>
              </div>

              <div className="hidden sm:flex items-center gap-1 bg-amber-50 text-amber-600 px-3 py-1.5 rounded-full text-sm font-bold">
                <Star size={15} fill="currentColor" />
                4.9
              </div>
            </div>

            {/* Route */}
            <div className="relative space-y-6">
              <div className="absolute left-5 top-11 h-14 border-l-2 border-dashed border-blue-200" />

              <div className="flex items-center gap-4">
                <div className="z-10 bg-blue-100 text-blue-600 p-2.5 rounded-full">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="font-bold">Chitkara University</p>
                  <p className="text-sm text-slate-500">Pickup Point</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="z-10 bg-emerald-100 text-emerald-600 p-2.5 rounded-full">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="font-bold">Sector 17, Chandigarh</p>
                  <p className="text-sm text-slate-500">Drop Location</p>
                </div>
              </div>
            </div>

            {/* Ride info */}
            <div className="grid grid-cols-3 gap-3 pt-8">
              <RideInfo icon={Clock} color="blue" title="10:00 AM" sub="Time" />
              <RideInfo icon={Users} color="violet" title="4 Seats" sub="Left" />
              <RideInfo icon={Car} color="emerald" title="Car" sub="Type" />
            </div>

            <button className="mt-7 w-full bg-gradient-to-r from-blue-600 to-violet-600 text-white py-3.5 rounded-2xl font-bold shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-violet-500/30 hover:-translate-y-0.5 transition-all">
              Book Ride
            </button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10 pb-24">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Built for the{" "}
            <span className="bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">
              student community
            </span>
          </h2>
          <p className="mt-3 text-slate-600">
            Safe, simple, and made exclusively for verified college students.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <FeatureCard icon={<GraduationCap />} title="Student Verified" desc="Only verified college students can book and share rides." color="blue" />
          <FeatureCard icon={<ShieldCheck />} title="Safe Travel" desc="Trusted drivers, verified profiles, and secure bookings." color="emerald" />
          <FeatureCard icon={<Users />} title="Community Rides" desc="Connect with students travelling on the same route." color="violet" />
          <FeatureCard icon={<Leaf />} title="Eco Friendly" desc="Share rides, reduce traffic, and save fuel together." color="green" />
        </div>
      </section>
    </div>
  );
}

function StatCard({ value, label, color }) {
  return (
    <div className="bg-white/90 backdrop-blur rounded-2xl p-4 border border-slate-100 shadow-sm hover:shadow-md transition">
      <p className={`text-2xl font-extrabold ${color}`}>{value}</p>
      <p className="text-xs text-slate-500 font-medium mt-0.5">{label}</p>
    </div>
  );
}

function RideInfo({ icon: Icon, color, title, sub }) {
  const map = {
    blue: "bg-blue-50 text-blue-600",
    violet: "bg-violet-50 text-violet-600",
    emerald: "bg-emerald-50 text-emerald-600",
  };
  return (
    <div className={`${map[color]} p-4 rounded-2xl text-center`}>
      <Icon className="mx-auto mb-2" size={22} />
      <p className="font-bold text-slate-900 text-sm sm:text-base">{title}</p>
      <p className="text-xs text-slate-500">{sub}</p>
    </div>
  );
}

function FeatureCard({ icon, title, desc, color }) {
  const colors = {
    blue: "bg-blue-100 text-blue-600",
    emerald: "bg-emerald-100 text-emerald-600",
    violet: "bg-violet-100 text-violet-600",
    green: "bg-green-100 text-green-600",
  };

  return (
    <div className="group bg-white rounded-3xl p-6 border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-blue-500/10 hover:-translate-y-1.5 transition-all">
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-5 ${colors[color]} group-hover:scale-110 transition`}>
        {React.cloneElement(icon, { size: 24 })}
      </div>
      <h3 className="text-lg font-bold text-slate-900 mb-2">{title}</h3>
      <p className="text-sm text-slate-500 leading-relaxed">{desc}</p>
    </div>
  );
}
