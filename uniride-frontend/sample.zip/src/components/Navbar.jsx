import React, { useContext } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

import {
  Car,
  LogOut,
  PlusCircle,
  Receipt,
  Shield,
  UserRound,
  LayoutDashboard,
} from "lucide-react";

import { AuthContext } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);

  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  const navClass = (path) =>
    `px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${
      isActive(path)
        ? "bg-blue-600 text-white shadow-lg shadow-blue-500/30"
        : "text-gray-300 hover:bg-white/10 hover:text-white"
    }`;

  const dashboard = () => {
    if (user?.role === "student") navigate("/student/dashboard");
    else if (user?.role === "driver") navigate("/driver/dashboard");
    else if (user?.role === "admin") navigate("/admin/dashboard");
  };

  return (
    <nav className="sticky top-0 z-50 bg-[#020617]/80 backdrop-blur-2xl border-b border-white/10">
      <div className="max-w-7xl mx-auto h-[78px] px-6 flex items-center justify-between gap-6">

        {/* LEFT LOGO */}
        <Link
          to="/"
          className="flex items-center gap-3 shrink-0"
        >
          <div className="bg-gradient-to-br from-blue-500 to-indigo-700 p-2.5 rounded-2xl shadow-lg shadow-blue-500/30">
            <Car className="text-white" size={22} />
          </div>

          <div className="leading-none">
            <h1 className="text-2xl font-black text-white">
              Uni<span className="text-blue-400">Ride</span>
            </h1>

            <p className="text-[10px] tracking-[0.25em] text-gray-400 font-bold mt-1">
              CHITKARA
            </p>
          </div>
        </Link>

        {/* CENTER NAVIGATION */}
        <div className="hidden lg:flex items-center gap-2 bg-white/5 border border-white/10 px-2 py-2 rounded-2xl">

          <Link to="/" className={navClass("/")}>
            Home
          </Link>

          {user?.role === "student" && (
            <>
              <Link
                to="/student/dashboard"
                className={navClass("/student/dashboard")}
              >
                <span className="flex items-center gap-2">
                  <LayoutDashboard size={16} />
                  Dashboard
                </span>
              </Link>

              <Link
                to="/student/bookings"
                className={navClass("/student/bookings")}
              >
                <span className="flex items-center gap-2">
                  <Receipt size={16} />
                  Bookings
                </span>
              </Link>
            </>
          )}

          {user?.role === "driver" && (
            <>
              <Link
                to="/driver/dashboard"
                className={navClass("/driver/dashboard")}
              >
                <span className="flex items-center gap-2">
                  <LayoutDashboard size={16} />
                  Dashboard
                </span>
              </Link>

              <Link
                to="/driver/create-ride"
                className={navClass("/driver/create-ride")}
              >
                <span className="flex items-center gap-2">
                  <PlusCircle size={16} />
                  Create
                </span>
              </Link>

              <Link
                to="/driver/my-rides"
                className={navClass("/driver/my-rides")}
              >
                <span className="flex items-center gap-2">
                  <Car size={16} />
                  My Rides
                </span>
              </Link>
            </>
          )}

          {user?.role === "admin" && (
            <>
              <Link
                to="/admin/users"
                className={navClass("/admin/users")}
              >
                Users
              </Link>

              <Link
                to="/admin/rides"
                className={navClass("/admin/rides")}
              >
                Rides
              </Link>

              <Link
                to="/admin/bookings"
                className={navClass("/admin/bookings")}
              >
                Bookings
              </Link>
            </>
          )}
        </div>

        {/* RIGHT SIDE */}
        <div className="flex items-center gap-3 shrink-0">

          {user ? (
            <>
              <button
                onClick={dashboard}
                className="flex items-center gap-3 bg-white/5 border border-white/10 px-4 py-2 rounded-2xl hover:bg-white/10 transition"
              >
                <div className="bg-gradient-to-br from-blue-500 to-indigo-700 p-2 rounded-xl">
                  {user.role === "admin" ? (
                    <Shield size={16} className="text-white" />
                  ) : (
                    <UserRound size={16} className="text-white" />
                  )}
                </div>

                <div className="leading-none hidden md:block">
                  <p className="text-sm font-bold text-white">
                    {user.name}
                  </p>

                  <p className="text-xs text-gray-400 capitalize mt-1">
                    {user.role}
                  </p>
                </div>
              </button>

              <button
                onClick={logout}
                className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-300 p-3 rounded-2xl transition"
              >
                <LogOut size={18} />
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="text-white border border-white/10 px-5 py-2.5 rounded-2xl hover:bg-white/10 transition"
              >
                Login
              </Link>

              <Link
                to="/register"
                className="bg-blue-600 hover:bg-blue-700 px-5 py-2.5 rounded-2xl font-bold text-white shadow-lg shadow-blue-500/30 transition"
              >
                Register
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}