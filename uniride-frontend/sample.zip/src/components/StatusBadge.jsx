import React from "react";

export default function StatusBadge({ status }) {
  const styles = {
    open: "bg-emerald-500/10 text-emerald-300 border-emerald-500/40",
    booked: "bg-emerald-500/10 text-emerald-300 border-emerald-500/40",
    full: "bg-yellow-500/10 text-yellow-300 border-yellow-500/40",
    cancelled: "bg-red-500/10 text-red-300 border-red-500/40",
    completed: "bg-indigo-500/10 text-indigo-300 border-indigo-500/40",
    pending: "bg-orange-500/10 text-orange-300 border-orange-500/40",
    paid: "bg-green-500/10 text-green-300 border-green-500/40",
    failed: "bg-red-500/10 text-red-300 border-red-500/40",
  };

  return (
    <span
      className={`px-4 py-1.5 rounded-full text-sm font-bold border ${
        styles[status] || "bg-gray-500/10 text-gray-300 border-gray-500/30"
      }`}
    >
      ● {status}
    </span>
  );
}