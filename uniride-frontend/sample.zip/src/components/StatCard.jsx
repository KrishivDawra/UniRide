import React from "react";

export default function StatCard({ title, value, icon: Icon, accent = "blue", change }) {
  const colors = {
    blue: "from-blue-600 to-indigo-600 border-blue-500/40",
    orange: "from-orange-500 to-yellow-600 border-orange-500/40",
    green: "from-emerald-500 to-green-700 border-emerald-500/40",
    red: "from-red-500 to-rose-700 border-red-500/40",
  };

  return (
    <div className={`relative overflow-hidden bg-[#0f172a]/90 border rounded-[28px] p-6 shadow-2xl ${colors[accent]?.split(" ").at(-1)}`}>
      <div className={`absolute left-0 top-0 h-full w-1 bg-gradient-to-b ${colors[accent]}`} />
      <div className={`absolute right-6 top-6 bg-gradient-to-br ${colors[accent]} p-4 rounded-2xl shadow-lg`}>
        {Icon && <Icon size={30} />}
      </div>

      <p className="text-gray-400 text-sm font-black tracking-widest uppercase">
        {title}
      </p>

      <h2 className="text-4xl font-black mt-3">{value}</h2>

      {change && (
        <p className="text-emerald-300 text-sm font-bold mt-4">
          ↑ {change}
        </p>
      )}
    </div>
  );
}