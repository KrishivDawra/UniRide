import React from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Calendar,
  Car,
  IndianRupee,
  MapPin,
  Ticket,
  UserRound,
} from "lucide-react";
import StatusBadge from "./StatusBadge";

export default function RideCard({ ride }) {
  return (
    <div className="relative overflow-hidden bg-[#0f172a]/90 border border-white/10 rounded-[28px] p-6 shadow-2xl hover:-translate-y-1 transition">
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-blue-500 via-cyan-400 to-orange-400" />
      <div className="absolute -right-20 -top-20 h-52 w-52 rounded-full bg-blue-500/20 blur-3xl" />

      <div className="relative flex justify-between items-start">
        <div>
          <p className="text-blue-400 font-black tracking-widest text-sm mb-4">
            AVAILABLE RIDE
          </p>

          <div className="flex items-center gap-4">
            <div className="bg-blue-600 p-3 rounded-2xl">
              <MapPin />
            </div>

            <h2 className="text-2xl font-black text-white">
              {ride.from} <span className="text-gray-400">→</span> {ride.to}
            </h2>
          </div>
        </div>

        <StatusBadge status={ride.status} />
      </div>

      <div className="relative mt-7 grid grid-cols-2 gap-4">
        <Info icon={Calendar} label="Departure" value={new Date(ride.time).toLocaleString()} />
        <Info icon={Car} label="Vehicle" value={ride.vehicleType} />
        <Info icon={IndianRupee} label="Seat Price" value={`₹${ride.seatPrice}`} />
        <Info icon={Ticket} label="Seats Left" value={`${ride.availableSeats}/${ride.seats}`} />
      </div>

      {ride.postedBy && (
        <div className="relative mt-5 bg-blue-50/10 border border-blue-400/20 rounded-3xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-3 rounded-2xl">
              <UserRound />
            </div>
            <div>
              <p className="text-blue-400 text-xs font-black tracking-widest">
                VERIFIED DRIVER
              </p>
              <p className="font-bold text-white">{ride.postedBy.name}</p>
            </div>
          </div>

          <span className="h-3 w-3 rounded-full bg-emerald-400" />
        </div>
      )}

      <Link
        to={`/ride/${ride._id}`}
        className="relative mt-6 flex justify-center items-center gap-2 bg-blue-600 hover:bg-blue-700 py-4 rounded-3xl font-black text-white"
      >
        View Ride Details
        <ArrowRight size={18} />
      </Link>
    </div>
  );
}

function Info({ icon: Icon, label, value }) {
  return (
    <div className="bg-black/20 border border-white/10 rounded-3xl p-4">
      <p className="text-gray-400 text-xs font-bold flex gap-2 items-center uppercase">
        <Icon size={15} className="text-blue-400" />
        {label}
      </p>
      <p className="font-black text-white mt-2">{value}</p>
    </div>
  );
}